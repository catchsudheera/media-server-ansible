<?php namespace App\SupportedApps\Kitana;

class Kitana extends \App\SupportedApps {

}