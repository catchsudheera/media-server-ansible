<?php namespace App\SupportedApps\Duplicacy;

class Duplicacy extends \App\SupportedApps {

}