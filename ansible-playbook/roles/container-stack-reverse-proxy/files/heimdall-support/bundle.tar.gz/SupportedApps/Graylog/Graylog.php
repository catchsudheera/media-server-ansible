<?php namespace App\SupportedApps\Graylog;

class Graylog extends \App\SupportedApps {

}