<?php namespace App\SupportedApps\NginxProxyManager;

class NginxProxyManager extends \App\SupportedApps {

}