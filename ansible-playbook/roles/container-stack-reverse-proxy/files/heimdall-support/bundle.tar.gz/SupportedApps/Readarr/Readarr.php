<?php namespace App\SupportedApps\Readarr;

class Readarr extends \App\SupportedApps {

}