<?php namespace App\SupportedApps\Ubooquity;

class Ubooquity extends \App\SupportedApps {

}