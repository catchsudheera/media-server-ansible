<ul class="livestats">
    <li>
        <span class="title">Temp.</span>
        <strong>{!! $temperature !!}&deg;C</strong>
    </li>
    <li>
        <span class="title">Humid.</span>
        <strong>{!! $humidity !!}&percnt;</strong>
    </li>
	<li>
        <span class="title">Dew.</span>
        <strong>{!! $dewpoint !!}&deg;C</strong>
    </li>
</ul>
