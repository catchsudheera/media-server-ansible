<?php namespace App\SupportedApps\UniFi;

class UniFi extends \App\SupportedApps {

}